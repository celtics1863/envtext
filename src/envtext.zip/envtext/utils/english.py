

def _wash_label(label):
    return label.strip() \
             .replace('  ','') \
             .lower() \
